﻿using Cignium.SearchFight.Interfaces;
using System.Collections.Generic;

namespace Cignium.SearchFight.Test
{
    public class QueryMakerMock : IQueryMaker
    {
        public IEnumerable<IResult> GetSearchEngines(IEnumerable<string> searchTerms)
        {
            return new List<IResult> { new SearchResultMock {SearchEngine="Google",Total=1000,SearchTerm=".net"},
                                             new SearchResultMock {SearchEngine="MSNSearch",Total=2000,SearchTerm=".net"},
                                             new SearchResultMock {SearchEngine="Google",Total=1000,SearchTerm="java"},
                                             new SearchResultMock {SearchEngine="MSNSearch",Total=2000,SearchTerm="java"} };
        }
    }
}
