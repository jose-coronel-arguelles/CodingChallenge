﻿using Cignium.SearchFight.Controller;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;


namespace Cignium.SearchFight.Test
{
    [TestClass()]
    public class SearchControllerTest
    {
        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CannotCreateControllerWithNullQueryMaker()
        {
          
            new SearchController(null);

        }


        [TestMethod()]
        public void SearchFightControllerReturnsValidViewModel()
        {
            var fakeQueryMaker = new QueryMakerMock();
            var searchFightCon = new SearchController(fakeQueryMaker);

            var sampleInput = new string[] { ".net", "java" };
            var viewModel = searchFightCon.StartSearchFight(sampleInput);

            var expectedViewModel = new ViewModel.SearchResultViewModel[] {  new ViewModel.SearchResultViewModel {Searcher="Google",Total=1000,ProgrammingLanguage=".net"},
                                                                 new ViewModel.SearchResultViewModel {Searcher="MSNSearch",Total=2000,ProgrammingLanguage="java"} };

            Assert.AreEqual(viewModel.Count(), expectedViewModel.Count());
            foreach (var searchResult in viewModel)
            {
                Assert.IsTrue(searchResult.Total > 0);
                int pos = Array.IndexOf(sampleInput, searchResult.ProgrammingLanguage);
                Assert.IsTrue(pos > -1);
            }
        }
    }
}
