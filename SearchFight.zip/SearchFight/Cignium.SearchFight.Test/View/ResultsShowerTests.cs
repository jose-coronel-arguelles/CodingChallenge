﻿using Cignium.SearchFight.Interfaces;
using Cignium.SearchFight.View;
using Cignium.SearchFight.ViewModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;

namespace Cignium.SearchFight.Test.View
{
    [TestClass()]
    public class ResultsShowerTests
    {
        [TestMethod()]
        public void GetResult_Language()
        {
            var searchResults = new List<SearchResultViewModel>();
            
            var lines = ShowResult.GetResult_Language(searchResults);

            var expectedLines = new List<string> {
                ".net: Google: 4450000000 MSN Search: 12354420 ",
                "java: Google: 966000000 MSN Search: 94381485 " };

            Assert.IsTrue(lines.Intersect(expectedLines).Count() == lines.Count());
        }

        [TestMethod()]
        public void GettingWinnerBySearchEngineReturnsExpectedLinesForOneSearchTerm()
        {
            var searchResults = new List<SearchResultViewModel> { 
                new SearchResultViewModel {Searcher="Google",Total=4450000000,ProgrammingLanguage=".net"},
                new SearchResultViewModel {Searcher="MSN Search",Total=94381485,ProgrammingLanguage="java"}};
            
            var lines = ShowResult.GetResult_Winner(searchResults);
            
            var expectedLines = new List<string> { "Google winner: .net", "MSN Search winner: java", "Total winner: Google" };

            Assert.IsTrue(lines.Intersect(expectedLines).Count() == lines.Count());
        }

    }
}
