﻿using Cignium.SearchFight.Interfaces;

namespace Cignium.SearchFight.Test
{
    public class SearchResultMock : IResult
    {
        public string SearchEngine { get ; set ; }
        public string SearchTerm { get ; set; }
        public long Total { get ; set; }
    }
}
