﻿using Cignium.SearchFight.Implement.SearchesEngine;
using Cignium.SearchFight.Test.HttpHandlerMocks;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace Cignium.SearchFight.Test.SearchEngines
{
    [TestClass()]
    public class GoogleTest
    {
        [TestMethod()]
        public void SearchingGoogleReturnsValidSearchResult()
        {
            //Arrange
            var fakeHttpHandler = new HttpHandlerMockGoogle();
            var google = new Google(fakeHttpHandler);

            //Act
            var searchResult = google.Search(".net");

            //Assert
            Assert.AreEqual(".net", searchResult.SearchTerm);
            Assert.AreEqual(1560000000, searchResult.Total);
            Assert.AreEqual("Google", searchResult.SearchEngine);

        }
    }
}
