﻿
using Cignium.SearchFight.Interfaces;

namespace Cignium.SearchFight.Implement
{
    public class SearchedResult:IResult
    {
        public string SearchTerm { get; set; }

        public long Total { get; set; }
        public string SearchEngine { get; set; }
    }
}
