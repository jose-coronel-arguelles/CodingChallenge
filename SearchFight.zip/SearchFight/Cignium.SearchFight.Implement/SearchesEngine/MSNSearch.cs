﻿using Cignium.SearchFight.Interfaces;

namespace Cignium.SearchFight.Implement.SearchesEngine
{
    public class MSNSearch : SearchEngine
    {

        /// <summary>
        /// API Bing needs 02 values connect and get data.
        /// </summary>
        public string apiKey = BingConfig.ApiKey;
        public string uri = BingConfig.BaseUrl;

        public MSNSearch(IHttpHandler httpHandler) : base(httpHandler)
        {

        }

        protected override string GetUrl(string searchTerm)
        {
            return uri + "?q=" + searchTerm;
        }

        protected override void AddRequestHeaders()
        {
            httpHandler.AddRequestHeader("Ocp-Apim-Subscription-Key", apiKey);
        }

        protected override long GetTotalResults(dynamic jObj)
        {
            return jObj["totalEstimatedMatches"];
        }
        public override string ToString()
        {
            return "MSN Search";
        }
    }
}
