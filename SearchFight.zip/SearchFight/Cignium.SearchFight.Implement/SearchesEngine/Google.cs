﻿using Cignium.SearchFight.Interfaces;
using System;

namespace Cignium.SearchFight.Implement.SearchesEngine
{
    public class Google:SearchEngine
    {
        /// <summary>
        /// API Google needs 03 values connect and get data.
        /// </summary>
        public string apiKey = GoogleConfig.ApiKey;
        public string customSearchEngineID = GoogleConfig.ContextId;
        public string uri = GoogleConfig.BaseUrl;

        public Google(IHttpHandler httpHandler) : base(httpHandler)
        {

        }

        protected override string GetUrl(string searchTerm)
        {
            return uri + "?key=" + apiKey + "&cx=" + customSearchEngineID + "&q=" + searchTerm;
        }

        protected override void AddRequestHeaders()
        {

        }
        protected override long GetTotalResults(dynamic jObj)
        {
            return Convert.ToInt64(jObj["queries"]["request"][0]["totalResults"]);
        }

        public override string ToString()
        {
            return "Google";
        }
    }
}
