﻿using System.Configuration;

namespace Cignium.SearchFight.Implement.SearchesEngine
{
    public class Config
    {
        #region Constants
        private const string MISSING_APIKEY = "Missing Value key";
        public const string TOTAL_TITLE = "Total winner:";
        public const string GOOGLE_URI = "Google.Uri";
        public const string GOOGLE_KEY = "Google.Key";
        public const string GOOGLE_SEARCH_ENGINE_ID = "Google.SearchEngineID";

        public const string BING_URI = "Bing.Uri";
        public const string BING_KEY = "Bing.Key";
        #endregion

        /// <summary>
        /// Gets configuration located in app.config. Method Created to get information about URL and Keys of APIs (Google and Bing)
        /// </summary>
        /// <param name="key">Atributo key del xml app.config. Value must be equal between the parameter and the key of app.config</param>
        /// <returns></returns>
        public static string GetValueFromConfigurationFile(string key)
        {
            string configurationValue = ConfigurationManager.AppSettings[key];  

            if (string.IsNullOrEmpty(configurationValue))
                throw new ConfigurationErrorsException(MISSING_APIKEY.Replace("{key}", key));

            return configurationValue;
        }
    }
}
