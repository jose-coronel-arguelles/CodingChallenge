﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cignium.SearchFight.Implement.SearchesEngine
{
    /// <summary>
    /// Class gets informtion from app.config
    /// </summary>
    public class BingConfig:Config
    {
        public static string BaseUrl => GetValueFromConfigurationFile(Config.BING_URI);
        public static string ApiKey => GetValueFromConfigurationFile(Config.BING_KEY);
    }
}
