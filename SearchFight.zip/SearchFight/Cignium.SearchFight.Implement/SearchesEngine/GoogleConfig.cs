﻿namespace Cignium.SearchFight.Implement.SearchesEngine
{
    public class GoogleConfig : Config
    {
        public static string BaseUrl => GetValueFromConfigurationFile(Config.GOOGLE_URI);
        public static string ApiKey => GetValueFromConfigurationFile(Config.GOOGLE_KEY);
        public static string ContextId => GetValueFromConfigurationFile(Config.GOOGLE_SEARCH_ENGINE_ID);
    }
}
