﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Cignium.SearchFight.Interfaces;

namespace Cignium.SearchFight.Implement
{
    public class HttpHandler : IHttpHandler
    {
        private HttpClient client;

        public HttpHandler()
        {
            client = new HttpClient();
            client.Timeout = TimeSpan.FromSeconds(10);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        }

        public Task<HttpResponseMessage> GetAsync(string url)
        {
            return client.GetAsync(url);
        }

        public void AddRequestHeader(string name, string value)
        {
            client.DefaultRequestHeaders.Add(name, value);
        }
    }
}
