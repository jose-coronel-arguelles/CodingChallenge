﻿using Cignium.SearchFight.Implement;
using Cignium.SearchFight.Implement.SearchesEngine;
using Cignium.SearchFight.Interfaces;
using SimpleInjector;

namespace Cignium.SearchFight.Dependencies
{
    public static class Container
    {

        private static SimpleInjector.Container container;
        public static SimpleInjector.Container BuildContainer()
        {
            container = new SimpleInjector.Container();
            container.Register<IQueryMaker, QueryMaker>(Lifestyle.Singleton);
            container.RegisterCollection<ISearchEngine>(new[] { typeof(Google), typeof(MSNSearch) });
            container.Register<IHttpHandler, HttpHandler>(Lifestyle.Singleton);
            container.Verify();
            return container;
        }
        
    }
}
