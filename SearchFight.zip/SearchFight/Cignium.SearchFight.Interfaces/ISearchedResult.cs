﻿namespace Cignium.SearchFight.Interfaces
{
    public interface ISearchedResult
    {
        IResult Search(string searchTerm);
    }
}
