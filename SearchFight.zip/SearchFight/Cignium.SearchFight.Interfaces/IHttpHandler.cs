﻿using System.Threading.Tasks;
using System.Net.Http;

namespace Cignium.SearchFight.Interfaces
{
    public interface IHttpHandler
    {
        Task<HttpResponseMessage> GetAsync(string url);
        void AddRequestHeader(string name, string value);
    }
}
