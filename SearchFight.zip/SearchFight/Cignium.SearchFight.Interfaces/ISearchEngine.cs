﻿namespace Cignium.SearchFight.Interfaces
{
    public interface ISearchEngine
    {
        IResult Search(string searchTerm);

    }
}
