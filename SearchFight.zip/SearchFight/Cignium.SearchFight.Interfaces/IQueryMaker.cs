﻿using System.Collections.Generic;

namespace Cignium.SearchFight.Interfaces
{
    public interface IQueryMaker
    {
        IEnumerable<IResult> GetSearchEngines(IEnumerable<string> searchTerms);
    }
}
