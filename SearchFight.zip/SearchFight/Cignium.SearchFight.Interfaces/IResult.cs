﻿
namespace Cignium.SearchFight.Interfaces        
{
    public interface IResult
    {
        string SearchEngine { get; set; }

        string SearchTerm { get; set; }

        long Total { get; set; }
    }
}
