﻿using Cignium.SearchFight.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Cignium.SearchFight.View
{
    public class ShowResult
    {

        /// <summary>
        /// Principal method used to show the informatio getting from APIs,
        /// </summary>
        /// <param name="result">View Model, result from the APIs</param>
        public static void Show(IEnumerable<SearchResultViewModel> result)
        {
            try
            {
                var linesLanguage = ShowResult.GetResult_Language(result);

                foreach (var item in linesLanguage)
                {
                    Console.WriteLine(item);
                }

                var linesWinner = ShowResult.GetResult_Winner(result);
                foreach (var item in linesWinner)
                {
                    Console.WriteLine(item);
                }

            }
            catch (Exception)
            {

                throw;
            }
        }


        /*
            
         */
        /// <summary>
        /// Get result grouped by Programming Language
        /// .net: Google: 4450000000 MSN Search: 12354420
        /// java: Google: 966000000 MSN Search: 94381485
        /// </summary>
        /// <param name="enumSearchResult"></param>
        /// <returns></returns>
        public static List<string> GetResult_Language(IEnumerable<SearchResultViewModel> enumSearchResult)
        {
            List<string> enumResult = new List<string>();
            try
            {
                var programmingLanguages = enumSearchResult.GroupBy(searchResultVM => searchResultVM.ProgrammingLanguage);

                foreach (var pl in programmingLanguages)
                {
                    var result = string.Format("{0}: ", pl.Key);

                    foreach (var searched in pl)
                    {
                        result += string.Format("{0}: {1} ", searched.Searcher, searched.Total);
                    }

                    enumResult.Add(result);
                }
            }
            catch (Exception)
            {

                throw;
            }
            return enumResult;
        }


        /// <summary>
        /// Gets results grouped by searches and show winners
        /// Google winner: .net
        /// MSN Search winner: java
        /// Total winner: .net
        /// </summary>
        /// <param name="searchResults"></param>
        /// <returns></returns>
        public static IEnumerable<string> GetResult_Winner(IEnumerable<SearchResultViewModel> enumSearchResult)
        {
            var results = new List<string>();
            string Total = String.Empty;
            var searchers = enumSearchResult.GroupBy(searchResultVM => searchResultVM.Searcher);

            foreach (var s in searchers)
            {
                var moreSearched = s.OrderByDescending(searchResultVM => searchResultVM.Total).First();
                Total = string.IsNullOrEmpty(Total) ? "Total winner: " + s.Key : Total;
                results.Add(string.Format("{0} winner: {1}", s.Key, moreSearched.ProgrammingLanguage));
            }
            results.Add(Total);

            return results;
        }

    }
}
