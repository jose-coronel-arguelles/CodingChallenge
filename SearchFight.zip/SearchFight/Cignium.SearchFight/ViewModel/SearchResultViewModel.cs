﻿namespace Cignium.SearchFight.ViewModel
{
    public class SearchResultViewModel  
    {
        public string Searcher { get; set; }
        public string ProgrammingLanguage { get; set; }
        public long Total{ get; set; }

    }
}
