﻿using Cignium.SearchFight.Controller;
using Cignium.SearchFight.Dependencies;
using Cignium.SearchFight.Interfaces;
using Cignium.SearchFight.View;
using System;

namespace Cignium.SearchFight
{
    class Program
    {
        static void Main(string[] searchTerms)
        {
            try
            {
                if (searchTerms.Length == 0)
                {
                    Console.WriteLine("No terms were specified for the Search Fight. Please execute again with the search terms.");
                    return;
                }
                Console.WriteLine("Executing Search Fight for: ");
                foreach (var item in searchTerms)
                {
                    Console.WriteLine("\t - " + item);
                }

                Console.WriteLine("Please wait...");

                var container = Container.BuildContainer();
                var queryMaker = container.GetInstance<IQueryMaker>();

                var searchFightCon = new SearchController(queryMaker);
                var viewModel = searchFightCon.StartSearchFight(searchTerms);
                
                ShowResult.Show(viewModel);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
