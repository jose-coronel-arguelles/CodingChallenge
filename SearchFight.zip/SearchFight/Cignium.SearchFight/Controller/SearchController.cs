﻿using Cignium.SearchFight.Interfaces;
using Cignium.SearchFight.ViewModel;
using System;
using System.Collections.Generic;

namespace Cignium.SearchFight.Controller
{
    public class SearchController
    {
        private readonly IQueryMaker queryMaker;

        public SearchController(IQueryMaker queryMaker)
        {
            if (queryMaker == null) throw new ArgumentNullException("queryMaker");
            this.queryMaker = queryMaker;
        }

        /// <summary>
        /// Get data from Searches Engines.
        /// </summary>
        /// <param name="searchTerms">Programing languaje: Java| .Net | Java Script</param>
        /// <returns></returns>
        public IEnumerable<SearchResultViewModel> StartSearchFight(string[] searchTerms)
        {
            var searchResults = queryMaker.GetSearchEngines(searchTerms);

            List<SearchResultViewModel> viewModel = new List<SearchResultViewModel>();

            foreach (var searchResult in searchResults)
            {
                viewModel.Add(new SearchResultViewModel()
                {
                    Searcher = searchResult.SearchEngine,
                    ProgrammingLanguage = searchResult.SearchTerm,
                    Total = searchResult.Total
                });
            }

            return viewModel;

        }
    }
}
